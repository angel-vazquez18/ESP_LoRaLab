#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <vector>
#include <Arduino.h>
#include <driver/i2s.h>
#include <driver/gpio.h>
#include <hal/i2s_ll.h>
#include "audio_manager.h"
#include "config.h"
#include "pins.h"

FakeSerial Serial;
static std::vector<int16_t> output;
static i2s_config_t configs[2];
static int failedPort = -1;
static int failedPinPort = -1;
static unsigned uninstallCount = 0, readSample = 0, queuedBlocks = 0;
static int writeMode = 0;  // 1 partial, 2 zero progress, 3 error, 4 misaligned
static bool stalledRead = false;
static uint8_t pcm[Config::AUDIO_BUFFER_BYTES];

// Model the driver's auto-start-on-install and enforce the amp's external
// startup contract. This cannot simulate the silicon's first clock edges.
FakeI2sHw fakeI2sHardware[2] = {{0}, {1}};
enum class InitFault { None, Stop, Clear, Monitor, BclkHigh, WsHigh, Enable, Start };
static InitFault initFault = InitFault::None;
static int levels[40];
static bool gpioOutputs[40];
static bool installed = false, running = false, routed = false;
static bool resetDone = false, silenceReady = false, leftFirst = false, continuous = false;
static unsigned starts = 0, stops = 0, enables = 0, installs = 0;
static uint64_t timeUs = 0, enabledAt = 0, disabledAt = 0;
static void freshHardware() {
  initFault = InitFault::None;
  memset(levels, 0, sizeof(levels));
  memset(gpioOutputs, 0, sizeof(gpioOutputs));
  installed = running = routed = resetDone = silenceReady = leftFirst = continuous = false;
  starts = stops = enables = installs = uninstallCount = 0;
  timeUs = enabledAt = disabledAt = 0;
  failedPort = failedPinPort = -1;
  output.clear();
}
void delay(uint32_t ms) { timeUs += ms * 1000ULL; }
void delayMicroseconds(uint32_t us) { timeUs += us; }
esp_err_t gpio_reset_pin(gpio_num_t p) {
  assert(levels[Pins::SPK_SD] == 0);
  gpioOutputs[p] = false;
  if (p == Pins::SPK_BCLK || p == Pins::SPK_WS) routed = false;
  return ESP_OK;
}
esp_err_t gpio_set_level(gpio_num_t p, uint32_t value) {
  if (p == Pins::SPK_SD) {
    if (value) {
      assert(installed && !running && routed && resetDone && silenceReady);
      assert(timeUs - disabledAt >= 1000);
      if (initFault == InitFault::Enable) return -1;
      enabledAt = timeUs;
      ++enables;
    } else { disabledAt = timeUs; }
  }
  levels[p] = value;
  return ESP_OK;
}
esp_err_t gpio_set_direction(gpio_num_t p, gpio_mode_t mode) {
  assert(mode == GPIO_MODE_OUTPUT && levels[p] == 0);
  gpioOutputs[p] = true;
  return ESP_OK;
}
esp_err_t gpio_input_enable(gpio_num_t) {
  return initFault == InitFault::Monitor ? -1 : ESP_OK;
}
int gpio_get_level(gpio_num_t p) {
  assert(!running && routed);
  if ((p == Pins::SPK_BCLK && initFault == InitFault::BclkHigh) ||
      (p == Pins::SPK_WS && initFault == InitFault::WsHigh)) return 1;
  return levels[p];
}
void i2s_ll_tx_reset(FakeI2sHw* hw) {
  assert(hw->port == 1 && installed && !running && !routed);
  resetDone = true;
}
void i2s_ll_tx_enable_right_first(FakeI2sHw* hw, bool right) {
  assert(hw->port == 1 && resetDone && !running);
  leftFirst = !right;
}
void i2s_ll_tx_stop_on_fifo_empty(FakeI2sHw* hw, bool stop) {
  assert(hw->port == 1 && !running);
  continuous = !stop;
}
const char* esp_err_to_name(esp_err_t) { return "FAKE_ERROR"; }
esp_err_t i2s_driver_install(i2s_port_t p, const i2s_config_t* c, int, void*) {
  ++installs;
  if (p == 1) {
    assert(!installed && !routed && levels[Pins::SPK_SD] == 0);
    for (auto pin : {Pins::SPK_BCLK, Pins::SPK_WS, Pins::SPK_DOUT})
      assert(gpioOutputs[pin] && levels[pin] == 0);
    if (p != failedPort) installed = running = true;
  }
  configs[p] = *c; return p == failedPort ? -1 : ESP_OK;
}
esp_err_t i2s_driver_uninstall(i2s_port_t p) {
  if (p == 1) {
    assert(installed && levels[Pins::SPK_SD] == 0 && timeUs - disabledAt >= 1000);
    installed = running = false;
  }
  ++uninstallCount; return ESP_OK;
}
esp_err_t i2s_stop(i2s_port_t p) {
  assert(p == 1 && installed && !routed && levels[Pins::SPK_SD] == 0);
  ++stops;
  if (initFault == InitFault::Stop) return -1;
  running = false;
  return ESP_OK;
}
esp_err_t i2s_start(i2s_port_t p) {
  assert(p == 1 && installed && !running && routed && leftFirst && continuous && silenceReady);
  assert(levels[Pins::SPK_SD] == 1 && timeUs - enabledAt >= 10);
  ++starts;
  // Also test cleanup when a failed API has already started the hardware.
  running = true;
  return initFault == InitFault::Start ? -1 : ESP_OK;
}
esp_err_t i2s_set_pin(i2s_port_t p, const i2s_pin_config_t* pins) {
  if (p == 1) {
    assert(installed && !running && resetDone && silenceReady && levels[Pins::SPK_SD] == 0);
    assert(pins->bck_io_num == Pins::SPK_BCLK && pins->ws_io_num == Pins::SPK_WS);
    assert(pins->data_out_num == Pins::SPK_DOUT);
    routed = true; // A failure can leave partially assigned pins.
  }
  assert(pins->mck_io_num == -1); return p == failedPinPort ? -1 : ESP_OK;
}
esp_err_t i2s_zero_dma_buffer(i2s_port_t p) {
  assert(p == I2S_NUM_1);  // RX must not be cleared in place.
  if (!running) {
    assert(resetDone && !routed);
    if (initFault == InitFault::Clear) return -1;
    silenceReady = true;
  }
  return ESP_OK;
}
esp_err_t i2s_write(i2s_port_t p, const void* data, size_t length, size_t* written, uint32_t timeout) {
  assert(p == I2S_NUM_1 && timeout == Config::I2S_TIMEOUT_MS);
  assert(running && levels[Pins::SPK_SD] == 1);
  assert(length <= Config::I2S_DMA_FRAMES * 4);
  *written = 0;
  if (writeMode == 2) return ESP_OK;
  if (writeMode == 3) return -1;
  if (writeMode == 4) { *written = 1; return ESP_OK; }
  *written = writeMode == 1 && length > 4 ? 4 : length;
  const auto* samples = static_cast<const int16_t*>(data);
  output.insert(output.end(), samples, samples + *written / 2);
  return ESP_OK;
}
static int32_t rawSample(unsigned index) {
  const int16_t high[] = {0, 100, -100, 20000, -20000, 1, -1, 1234};
  return static_cast<int32_t>(high[index % 8]) * 65536;
}
esp_err_t i2s_read(i2s_port_t p, void* data, size_t length, size_t* read, uint32_t timeout) {
  assert(p == I2S_NUM_0);
  *read = 0;
  if (timeout == 0) {
    if (queuedBlocks) { --queuedBlocks; memset(data, 0x55, length); *read = length; }
    return ESP_OK;
  }
  assert(timeout == Config::I2S_TIMEOUT_MS);
  if (stalledRead) return ESP_OK;
  auto* words = static_cast<int32_t*>(data);
  for (size_t i = 0; i < length / 4; ++i) words[i] = rawSample(readSample++);
  *read = length;
  return ESP_OK;
}

int main() {
  freshHardware();
  AudioManager audio;
  assert(!audio.playTestTone());
  assert(audio.begin());
  assert(audio.microphoneReady() == Config::ENABLE_MIC);
  assert(audio.speakerReady() == Config::ENABLE_SPEAKER);
  assert(installs == unsigned(Config::ENABLE_MIC) + unsigned(Config::ENABLE_SPEAKER));
  const auto initializedAt = timeUs;
  assert(audio.begin() && timeUs == initializedAt); // No repeated shutdown/init.
  if (!Config::ENABLE_SPEAKER) {
    assert(levels[Pins::SPK_SD] == 0 && !running && !audio.playTestTone());
    puts("PASS: serial-only holds SD low and installs no I2S drivers");
    return 0;
  }
  assert(starts == 1 && stops == 1 && enables == 1);
  assert(timeUs - enabledAt >= Config::AMP_STARTUP_SETTLE_MS * 1000ULL);
  if (!Config::ENABLE_MIC) {
    assert(audio.playTestTone() && running && starts == 1 && stops == 1);
    puts("PASS: speaker-only sequenced startup, no microphone dependency");
    return 0;
  }
  assert(configs[0].bits_per_sample == 32 && configs[0].channel_format == I2S_CHANNEL_FMT_ONLY_LEFT);
  assert(configs[1].bits_per_sample == 16 && configs[1].channel_format == I2S_CHANNEL_FMT_RIGHT_LEFT);
  writeMode = 1;  // Force many valid short writes; no samples may be skipped.
  assert(audio.playTestTone(1000));
  const size_t tail = (Config::I2S_DMA_BUFFERS + 1) * Config::I2S_DMA_FRAMES;
  assert(output.size() == (8000 + tail) * 2);
  for (size_t i = 0; i < output.size() / 2; ++i) {
    const int16_t expected = i >= 8000 ? 0 : (i % 8 < 4 ? 2000 : -2000);
    assert(output[i * 2] == expected && output[i * 2 + 1] == expected);
  }
  for (int mode = 2; mode <= 4; ++mode) {
    writeMode = mode;
    assert(!audio.playTestTone());
    assert(!audio.playPcm(pcm, sizeof(pcm)));
  }
  writeMode = 0;
  queuedBlocks = 7;
  assert(audio.recordThreeSeconds(pcm, sizeof(pcm)));
  assert(readSample == Config::MIC_DMA_WORDS + Config::AUDIO_SAMPLES);
  for (size_t i = 0; i < Config::AUDIO_SAMPLES; ++i) {
    int32_t expected = (rawSample(i + Config::MIC_DMA_WORDS) >> 16) * Config::MIC_GAIN;
    if (expected > 32767) expected = 32767;
    if (expected < -32768) expected = -32768;
    int16_t value;
    memcpy(&value, pcm + i * 2, 2);
    assert(value == expected);
  }
  output.clear();
  assert(audio.playPcm(pcm, sizeof(pcm)));
  assert(output.size() == (Config::AUDIO_SAMPLES + tail) * 2);
  for (size_t i = 0; i < Config::AUDIO_SAMPLES; ++i) {
    int16_t value; memcpy(&value, pcm + i * 2, 2);
    assert(output[i * 2] == value && output[i * 2 + 1] == value);
  }
  for (size_t i = Config::AUDIO_SAMPLES * 2; i < output.size(); ++i) assert(output[i] == 0);
  stalledRead = true;
  assert(!audio.recordThreeSeconds(pcm, sizeof(pcm)));
  stalledRead = false;
  queuedBlocks = 100;  // A queue that never drains must fail within a fixed bound.
  assert(!audio.recordThreeSeconds(pcm, sizeof(pcm)));
  queuedBlocks = 0;
  assert(!audio.recordThreeSeconds(nullptr, sizeof(pcm)));
  assert(!audio.recordThreeSeconds(pcm, sizeof(pcm) - 1));
  assert(!audio.playPcm(nullptr, sizeof(pcm)));
  assert(!audio.playPcm(pcm, sizeof(pcm) - 1));
  assert(!audio.playTestTone(0) && !audio.playTestTone(10001));
  audio.stopSpeaker();
  assert(running && starts == 1 && stops == 1 && enables == 1);
  assert(audio.begin());
  assert(starts == 1 && stops == 1 && enables == 1);
  freshHardware();
  failedPort = I2S_NUM_0;
  AudioManager speakerOnly;
  assert(!speakerOnly.begin() && !speakerOnly.microphoneReady() && speakerOnly.speakerReady());
  assert(speakerOnly.playTestTone());
  freshHardware();
  failedPinPort = I2S_NUM_1;
  AudioManager pinFailure;
  assert(!pinFailure.begin() && pinFailure.microphoneReady() && !pinFailure.speakerReady());
  assert(uninstallCount == 1);
  assert(!running && !installed && !routed && levels[Pins::SPK_SD] == 0);
  freshHardware();
  failedPort = I2S_NUM_1;
  AudioManager installFailure;
  assert(!installFailure.begin() && installFailure.microphoneReady() && !installFailure.speakerReady());
  assert(!running && !installed && levels[Pins::SPK_SD] == 0 && uninstallCount == 0);
  for (auto fault : {InitFault::Stop, InitFault::Clear, InitFault::Monitor,
                    InitFault::BclkHigh, InitFault::WsHigh, InitFault::Enable, InitFault::Start}) {
    freshHardware();
    initFault = fault;
    AudioManager failure;
    assert(!failure.begin() && failure.microphoneReady() && !failure.speakerReady());
    assert(!installed && !running && !routed && levels[Pins::SPK_SD] == 0);
    assert(uninstallCount == 1 && !failure.playTestTone());
    const auto failedAt = timeUs;
    assert(!failure.begin() && timeUs == failedAt); // Reset required; no unsafe retry.
  }
  puts("PASS: amp startup ordering/delay, continuous clocks, idempotence, fail-closed cleanup");
  puts("PASS: audio stereo/tone samples, partial/failed I/O, capture queue, conversion/clipping, buffer guards, init isolation");
}
