#pragma once
#include <stddef.h>
#include <stdint.h>
enum gpio_num_t { GPIO_NUM_4 = 4, GPIO_NUM_14 = 14, GPIO_NUM_16 = 16,
                 GPIO_NUM_17 = 17, GPIO_NUM_25 = 25, GPIO_NUM_26 = 26,
                 GPIO_NUM_27 = 27, GPIO_NUM_33 = 33 };
struct FakeSerial {
  template <typename... Args> void printf(const char*, Args...) {}
  void println(const char* = "") {}
  void print(const char*) {}
};
extern FakeSerial Serial;
void delay(uint32_t ms);
void delayMicroseconds(uint32_t us);
