# ESP32 audio bench continuation

For the 2026-11-05 source snapshot, project scope, and repository handoff, start
with [README_HANDOFF.md](README_HANDOFF.md). A copyable integration request is in
[INTEGRATION_PROMPT.md](INTEGRATION_PROMPT.md).

This is a diagnostic continuation of the supplied `esp32-audio-chunker-test.zip`.
The immediate milestone is an audible, repeatable MAX98357A tone followed by
verified microphone capture. See [BENCH_VALIDATION.md](BENCH_VALIDATION.md) for the
exact wiring, measurements, fault isolation, and acceptance sequence.

**Startup-sequence build:** before uploading, power off and move MAX98357A SD
(breadboard row 28) from the 3V3 rail to **GPIO27**. Fit a 1 kOhm SD-to-GND pulldown
and verify SD stays below 0.08 V while ESP32 reset is held. This firmware drives
SD low, prepares the stopped I2S transmitter, then enables SD 20 microseconds
before starting continuous 256 kHz / 8 kHz clocks. Existing audio data and PTT
architecture are preserved. See the bench guide for required first-edge scope
checks. The user has since confirmed an audible tone after reconnecting cabling;
physical first-edge timing has not been captured.

The architecture remains store-and-forward, half-duplex PTT: capture 24,000 mono
samples (3 seconds at nominal 8 kHz), retain 48,000 bytes of signed 16-bit PCM,
create 200 indexed 247-byte packets, reassemble, then play. Transport is currently
simulated in RAM. The two large buffers remain global/object storage; the
`VoiceChunker` object must never be instantiated on an ESP32 task stack.

## Build and commands

Open this directory in PlatformIO. The installed baseline was Espressif32 8.0.0,
Arduino-ESP32 3.3.12, ESP-IDF 5.5.5, targeting `esp32dev`. The platform is now pinned
to 8.0.0. The shared build flags set `CONFIG_I2S_SUPPRESS_DEPRECATE_WARN=1`
and `CONFIG_ADC_SUPPRESS_DEPRECATE_WARN=1` to suppress the two known legacy-driver
header notices (ADC is included indirectly by I2S). All three environments inherit
these flags; other compiler warnings remain enabled. This controls diagnostics
only and does not migrate the driver or change audio behavior. Remove these flags
when migrating away from legacy I2S after hardware validation. See the
[ESP-IDF warning configuration](https://docs.espressif.com/projects/esp-idf/en/v5.5.5/esp32/api-reference/kconfig-reference.html#config-i2s-suppress-deprecate-warn).

```powershell
pio run -e esp32dev
pio run -e speaker_only
pio run -e serial_only
```

If `pio` is not on PATH, invoke
`& "$env:USERPROFILE\.platformio\penv\Scripts\pio.exe"` in its place.

For upload, close any serial monitor first and use the environment for the bench
stage. COM4 is the previously reported port; verify it still belongs to this board.

```powershell
pio run -e speaker_only -t upload --upload-port COM4
pio device monitor -p COM4 -b 115200
```

| Command | Function |
|---|---|
| `s` | Exactly 8,000 frames of a 1 kHz square wave, identical L/R, amplitude ±2000 |
| `t` | Existing deterministic reverse-order 200-packet integrity test |
| `m` | Record only, then print PCM statistics and eight raw I2S words |
| `d` | Export last successful recording with CRC-32; use the PC script below |
| `r` | Record, print statistics, direct playback |
| `p` | Record, packetize, simulate transfer, verify every reconstructed byte, play |
| `l` | Toggle loss between zero and indices 17, 34, …, 187 (11 lost chunks) |
| `i` | Firmware/build versions, reset reason, uptime, heap, readiness and pins |
| `x` | Packet layout |
| `h` | Toggle heartbeat; enabled on reset |

PTT stays disabled by `Config::ENABLE_PTT = false`. Its eventual switch is GPIO4
to GND with the internal pull-up. Current commands block while a local operation
runs; this is still a bench harness, not the future radio state machine. A held
PTT records one fixed three-second clip, not an indefinite stream.

## Changes and evidence

| Finding in supplied source | Diagnostic change |
|---|---|
| Tone/playback return values were ignored | Failure messages now reflect returned status |
| TX used left-only 16-bit slots | Duplicate mono into explicit stereo slots, avoiding channel-selection ambiguity and ESP32 mono sample-order quirks |
| Tone immediately cleared queued TX data | Queue more than one DMA ring of silence before clearing, preserving the final audio samples |
| Recording cleared RX memory without draining its queue | Discard pending data plus the next boundary block before collecting exactly 24,000 samples |
| I/O waited indefinitely and trusted ESP_OK | Bounded small transfers, byte-count checks, partial-write handling, zero-progress rejection |
| No microphone amplitude evidence | Min/max, mean/DC, AC RMS, zero/clipped counts, and raw words |
| One I2S init failure blocked all testing | Keep serial/chunker tests and any independently working audio direction available |
| Protocol accepted payload lengths 0–240 | Require exactly 240 bytes for fixed-size version 1; malformed packets cannot count toward completion |
| Intermittent corrupt serial lacked context | Build ID, reset reason and increasing uptime; separate serial-only/speaker-only builds |
| 256 kHz startup had SD permanently enabled | GPIO27 shutdown/enable sequence, stopped-pin routing, silent DMA, idle-level check and continuous clocks |

Historical build figures, before the startup-sequence change: the unmodified archive compiled successfully before edits: 118,356 bytes static
RAM, 318,612 bytes flash. The full diagnostic build also compiled successfully:
118,356 bytes static RAM, 324,356 bytes flash. Runtime I2S DMA allocations are
additional to the static RAM figure. Stereo TX increases its DMA allocation by
about 2 KB, without increasing either 48 KB PCM buffer.

Both isolation environments compiled successfully as well: `speaker_only`
(118,356 bytes static RAM / 324,072 bytes flash), and `serial_only`
(118,164 bytes static RAM / 306,220 bytes flash).

The queue behavior was checked against the [ESP-IDF 5.5.5 legacy I2S driver](https://github.com/espressif/esp-idf/blob/v5.5.5/components/driver/deprecated/i2s_legacy.c).
Espressif documents the original ESP32's 16-bit mono ordering caveat in its
[I2S reference](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/peripherals/i2s.html).

Host tests compile the actual chunker and audio sources. Audio tests substitute
I2S calls and therefore verify software behavior, not ESP32 timing or electrical
signals. They cover ordering, duplicate retention, malformed/truncated packets,
message reset, first/last/interior loss, exact tone and PCM samples, partial and
failed writes, queue draining, conversion/clipping, and independent init failure.
Startup tests additionally enforce enable-before-clock ordering and delay,
continuous clocks through playback/errors, idempotent initialization, and SD-low
cleanup after install/stop/clear/pin/monitor/enable/start failures. The audio suite
also runs with the `speaker_only` and `serial_only` compile-time settings.

```powershell
.\test\host\run.ps1
# Optional alternate MinGW compiler:
.\test\host\run.ps1 -Compiler 'C:\path\to\g++.exe'
```

The startup firmware was built and uploaded after the GPIO27 wiring change.
The user subsequently confirmed that the tone works after reconnecting cabling.
No individual loose connection was isolated. Host tests substitute peripherals
and cannot establish physical timing or audible quality. No RF test is included.

## Recording noise diagnostics

### Recording console: record, play and save in one console

Close PlatformIO/Arduino's serial monitor first (only one program can own COM4).
From this project's PowerShell terminal, run:

```powershell
.\tools\record-monitor.ps1
# If PowerShell script execution is restricted, run Python directly:
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" -u .\tools\record_monitor.py --port COM4
```

At the `record>` prompt, type a command and press Enter:

```text
m quiet
m whisper
m normal
r playback_check
q
```

Enter each recording command separately. Wait for **Speak now**, record for three
seconds, then wait for **SAVED** before the next command. Plain `m` works too;
labels are optional. `r [label]` records for three seconds, plays that recording
through the ESP32 speaker, then saves the same PCM as a WAV. For the matched
speaker/PC comparison, enter `r playback_check` and listen during playback; wait
for **SAVED** before opening its WAV on the PC. No console switching is needed.
`d [label]` saves the last recording without recording again.
`q` closes the console and releases COM4. Ctrl+C also releases the port; if used
during a transfer, wait for the ESP32 to finish before reopening the console.

Every successful command creates a new folder under this project's `captures/`,
independent of the terminal's working directory:

```text
captures/20261102-153000-123456-whisper/
    recording.wav
    recording.json
    recording.svg
    recording.serial.txt
```

The WAV preserves the original level (8 kHz, 16-bit mono). JSON contains the label,
UTC request/receipt times, checksum, amplitude/rail/zero statistics and, for new
recordings, the firmware's raw-word and clipping diagnostics. For `r`, JSON also
marks direct playback and its digital completion status; this does not confirm
audible quality. SVG shows the whole
recording and its first 100 ms. The serial log retains text diagnostics without
binary audio. Failed attempts retain `error.json` and the log; invalid/truncated
transfers never produce a WAV. Failed folders should not be used as completed
captures. Existing captures are never overwritten and `captures/` is git-ignored.

This is a **PC recording console**, not a firmware filesystem: `m` sends the
firmware's `m`, waits for successful recording, then requests `d` and validates
the length and CRC. `r` sends the firmware's `r`, waits for successful recording,
direct playback completion and IDLE, then requests `d` without recording again.
If recording/playback fails or times out, it does not automatically export or
retry. After a playback failure, `d [label]` can export the retained recording
separately once the ESP32 has finished.
An ordinary serial monitor still only prints statistics when `m` is pressed.
There is no live streaming, and no firmware change/upload is needed
if `audio-bench-3-pcm-export` is already installed. Audio gain, I2S, amplifier
startup, and the asynchronous PTT architecture are unchanged.

After recording, share the capture folder names for analysis. Saving computes
measurements locally; it does not automatically start a new assistant analysis.

For a single unattended capture or exporting an existing one:

```powershell
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" -u .\tools\record_monitor.py --port COM4 --once normal
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" -u .\tools\record_monitor.py --port COM4 --once saved-earlier --export
```

### Existing one-shot export tool

Revision `audio-bench-3-pcm-export` preserves the capture conversion, gain,
speaker startup and packet format. It adds counts of raw zero/all-one words and
the longest identical-word run. Command `d` exports the last complete recording
as 48,000 binary bytes between a format/CRC header and an end marker. A failed
recording or `t` invalidates that buffer. No new large firmware buffer is used.
Do not type `d` into a text monitor: use this script, which checks the byte count
and CRC before writing a WAV. The export itself takes about five seconds and
does not play the speaker or start a new recording.

Close the IDE serial monitor, then run from this project directory:

```powershell
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" .\tools\capture_audio.py --port COM4 --record --out .\captures\quiet-01
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" .\tools\capture_audio.py --port COM4 --record --out .\captures\speech-01
```

Each command provides a five-second cue before a three-second capture. Stay quiet
for the first and speak normally near the microphone for the second. Omit
`--record` to export a recording already made with `m`, `r` or `p`. Use a new name
each time. Outputs: original-level `.wav`, `.json` measurements, `.svg` waveform
and `.serial.txt` log. Start PC playback volume low if the recording clips.

On 2026-11-02, two captures from the preceding firmware each contained about 40%
exact-zero PCM samples and 158/161 clipped samples out of 24,000, with raw previews
entirely zero or `ffffffff`. Acoustic conditions were not controlled. These are
capture-path symptoms; they do not establish a broken microphone or justify
filtering/gain changes. Compare digital WAV quality with speaker playback.

Inspect the INMP441 pins at the module, not only the breadboard row:

| Mic pin | Connection / expected measurement |
|---|---|
| VDD | ESP32 3V3, approximately 3.3 V to mic GND during recording |
| GND | Common ESP32 ground |
| L/R | GND, selecting left channel; do not leave floating |
| SCK/BCLK | GPIO26, nominal 512 kHz |
| WS | GPIO25, nominal 8 kHz |
| SD | GPIO33, digital data; not the amplifier's SD/enable pin |

With power disconnected, check continuity from module solder pads to the ESP32
pins. At the microphone, the scope should show 64 SCK periods per WS frame.
Use matching x10 probe/channel settings, DC coupling and a short ground lead to
mic GND. The INMP441 datasheet specifies a 100 kOhm SD-to-GND pulldown for its
tri-stated intervals and 0.1 uF supply bypassing; check whether the breakout
already includes these. Its bottom acoustic port must remain unobstructed.
Source: [TDK INMP441 datasheet, pages 8, 11 and 15](https://product.tdk.com/system/files/dam/doc/product/sw_piezo/mic/mems-mic/data_sheet/inmp441.pdf).
Keep the validated amplifier wiring in place; never attach a scope ground clip
to either speaker output.

Export/parser tests (in addition to the existing host audio/chunker suite):

```powershell
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" .\test\host\capture_audio_test.py
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" .\test\host\record_monitor_test.py
```

## Provenance and deferred work

Original archive: `C:\Users\Homar\Documents\Arduino\esp32-audio-chunker-test.zip`.
SHA-256: `608C6A8EEA7C0E14587E00122B368FFFD490DE113FF18B3DCF33B24E036B096D`.
It was left unchanged. Only source/configuration files were extracted; cached
builds and generated VS Code files were excluded. The supplied briefing was used
as historical context and checked against the source, not treated as proof of
present hardware behavior.

Before radio work, pass the bench gates. Then add RadioLib/SX1262 transport,
airtime-based receive inactivity timeout and explicit message ownership. The
current reassembler intentionally resets on **any differing message ID**; a late
old packet or second sender can therefore erase an assembly. This unchanged
behavior is acceptable only for the local test, not a completed radio receiver.
Packed message IDs currently use ESP32 little-endian layout; a future radio
boundary should serialize explicitly. RF CRC, sender identity, retransmission,
authentication, contention and regulatory operation remain separate work.

Heltec V4 pins and its PA/RF control, power, SPI and exposed headers require the
exact purchased board revision's schematic. No V4 pin mapping or build has been
validated here. Compression and I2S API migration remain deferred until the
baseline audio and then radio behavior are measured.
