# ESP-WROOM-32 audio validation

Current bench evidence (before the startup-sequence change): firmware was uploaded
to COM4, but the speaker remained silent. The user measured VIN 4.995 V, SD 3.322 V
and GAIN 0 V. The FNIRSI 2C53T showed BCLK 256 kHz, LRC 8 kHz, and repeatable DIN
activity during `s`. DIN activity does not prove correctly decoded PCM. The speaker
is an Alrhso 1 W / 8 ohm cavity speaker, soldered across the output pads. Header and
speaker continuity, startup edge timing, and amplifier output remain to be checked.

## Wiring for the current ESP-WROOM-32 only

Use the GPIO number printed on the board, not the physical header position.
Power off USB and any external supply before changing connections.

| Module terminal | Connection | Check |
|---|---|---|
| MAX98357A LRC | GPIO16 | Word-select, not VIN |
| MAX98357A BCLK | GPIO14 | Bit clock |
| MAX98357A DIN | GPIO17 | Audio data from ESP32 |
| MAX98357A GAIN (row 27) | GND, as presently wired | Keep this gain setting during the startup comparison |
| MAX98357A SD (row 28) | **GPIO27**, plus 1 kOhm to GND | Remove the existing direct connection to 3V3 before upload |
| MAX98357A GND | ESP32 GND | Short, reliable common ground |
| MAX98357A VIN | Verified regulated 5 V bench/USB rail | Confirm the development board's 5V/VIN pin actually supplies this voltage |
| Speaker leads | Amplifier SPK+ and SPK− | Neither speaker lead connects to GND |
| INMP441 VDD | ESP32 3V3 | Never 5 V |
| INMP441 GND | ESP32 GND | Shared reference |
| INMP441 SCK/BCLK | GPIO26 | Microphone bit clock |
| INMP441 WS | GPIO25 | Microphone word-select |
| INMP441 SD | GPIO33 | Microphone audio output; different function from amplifier SD |
| INMP441 L/R | GND | Select left channel to match firmware |
| PTT | GPIO4 to normally-open switch to GND | Leave disabled during audio tests |

GPIO14 also has a JTAG function. GPIO16/17 are usable here on the stated WROOM
board; don't transfer this map to WROVER/PSRAM or S3 boards. Avoid changing boot
straps GPIO0/2/5/12/15 during diagnosis. GPIO1/3 are the usual UART0 serial pins;
the GPIO16/17 speaker assignment does not itself conflict with that UART.
See [Espressif's GPIO reference](https://docs.espressif.com/projects/esp-idf/en/v4.4.2/esp32/api-reference/peripherals/gpio.html)
and [WROOM-32 pin definitions](https://documentation.espressif.com/esp32-wroom-32_datasheet_en.html).

The MAX98357A accepts standard I2S; the MAX98357B uses left-justified data.
Confirm the module is A if correctly decoded I2S still produces no sound. SD is
an analog mode input. Typical boundaries are about 0.16 V (shutdown), 0.77 V and
1.4 V (channel selection); use clear margins, not boundary voltages. Identical
left/right data in this build works with any enabled channel selection.
See the [MAX98357A/B datasheet, SD_MODE and serial-interface sections](https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf).

SD is now driven by GPIO27. **Do not leave row 28 connected directly to 3V3:** the
new firmware drives it low during startup. Power off before moving that jumper.
Add a 1 kOhm resistor from SD to GND to keep the amplifier off while ESP32 reset
leaves GPIO27 undriven. With ESP32 EN/reset held low, verify SD below 0.08 V; this
also checks whether an unknown breakout pull-up defeats the resistor. A low
firmware output should be near 0 V; once initialized, SD should be about 3.3 V.
This input also selects the left channel when high; both slots contain identical
audio. The resistor draws about 3.3 mA when enabled. Do not drive amplifier inputs
while its VIN is absent. Keep the present common USB-derived supply for this test.

## MAX98357A 256 kHz startup sanity check

This build implements the software ordering for the special 256 kHz / 8 kHz
startup described in the [MAX98357A/B datasheet, Startup and Figure 6](https://www.analog.com/media/en/technical-documentation/data-sheets/max98357a-max98357b.pdf).
It preserves the existing sample format, duplicated stereo data, tone level and
record/buffer/chunk/reassemble/playback flow.

1. Hold SD low for at least 1 ms and drive BCLK/LRC/DIN low.
2. Install the I2S driver with its output pins disconnected. The legacy driver's
   automatic start therefore does not send clocks to the amplifier.
3. Stop/reset the transmitter, select the left slot first, prepare silent DMA
   buffers, and then route the stopped signals to the pins. Abort with SD low
   if BCLK or LRC reads high at this point.
4. Raise SD, wait 20 microseconds (datasheet minimum 10 microseconds), then start
   the transmitter. Allow 20 ms of startup silence before commands run.
5. Leave clocks running between commands, including playback errors. An init
   failure lowers SD before uninstalling the driver. Repeated `begin()` calls
   return the original result; resetting the board is required to retry.

This is specific to the original ESP32 and the pinned ESP-IDF 5.5.5 legacy driver.
The hardware serializer generates BCLK/LRC together; software delays do not prove
the first-edge relationship. VIN is not sensed. A successful `begin()` or `SPK
ready=1` reports software initialization, not verified MAX98357A operation.

After rewiring, build before uploading. Expect banner
`audio-bench-2-max98357-startup`. On the FNIRSI use matched physical/channel x10
settings, DC coupling, about 1 V/div for logic, and a short ground connection at
amplifier GND (row 29). Both channel ground clips go there, never to speaker pads.
Capture at the amplifier terminals, not just the breadboard jumper sockets:

- **SD versus BCLK:** CH1 on SD, CH2 on BCLK. Hold ESP32 EN/reset low, arm a single
  rising-edge trigger on CH1 around 1.5 V, then release reset. Start near 10 us/div.
  Confirm BCLK stays low until at least 10 us after SD rises. Confirm VIN is already
  stable near 5 V; startup assumes it is above 2.3 V before the delay begins.
- **First BCLK versus first LRC:** CH1 on BCLK, CH2 on LRC. Hold reset low, arm a
  single rising-edge trigger on CH1 around 1.5 V, then release reset. Use about
  10 us/div with pretrigger visible. Both must begin low and transition high;
  the first LRC rising edge must follow the first BCLK rising edge by at least
  half a BCLK period and at most half an LRC period: 1.953125 to 62.5 us.
- Then check full LRC periods of 125 us, BCLK at 256 kHz, and uninterrupted clocks
  before, during and after repeated `s` commands. If startup aborts, save the
  `[AMP]` and `[I2S]` log; do not bypass the idle-level check to force enable.

If those edge checks fail, this implementation has not satisfied the electrical
sequence and needs adjustment. If they pass but the speaker stays silent, continue
with speaker continuity and amplifier-output checks below; do not conclude that
the amp is damaged from DIN activity alone. Neither physical startup timing nor
audible output has been verified for this new build.

## Gate 1: passive checks and serial baseline

1. Unplug all power. Disconnect both audio modules completely, including signal
   wires. Inspect for misplaced breadboard rows and split power rails. Check
   continuity from each ESP32 pin to its intended module terminal with one wire
   at a time; the wire's colour is not evidence of its destination.
2. Disconnect the speaker from the amp and measure across its two leads. Expect
   a finite resistance of a few ohms for a typical 4 Ω or 8 Ω speaker; DC
   resistance is usually below rated impedance. Open circuit, near-zero after
   subtracting test-lead resistance, or intermittent readings require investigation.
3. Check the unpowered amp's VIN-to-GND resistance for a sustained short.
   Charging capacitors can make the reading change; a continuity beep alone
   neither proves nor disproves a fault. Never measure resistance on a live rail.
4. Upload `serial_only`, then run `i` and `t`. Confirm the `audio-bench-2-max98357-startup` banner,
   both audio directions disabled, the test passes and the heartbeat stays
   readable for at least 60 seconds. Record uptime and any boot/banner repetition.
5. If corruption occurs with all peripherals removed, use one serial terminal
   at 115200, 8N1, no flow control, and try a known-good data USB cable/port.
   Compare a raw terminal against PlatformIO's filtered display. Decoder notices
   alone are not evidence of an exception; preserve the actual bytes/reset log.

Optional raw serial monitor using the installed PlatformIO Python:

```powershell
& "$env:USERPROFILE\.platformio\penv\Scripts\python.exe" -m serial.tools.miniterm COM4 115200 --raw
```

Close other monitors first. Opening a serial port may reset the board through
DTR/RTS; distinguish that from unsolicited resets during steady operation.

**Pass:** stable readable serial with increasing uptime, and `t` passes. A
recurring banner or restarted uptime means a reset occurred; continuing output
after corruption alone does not rule one out.

## Gate 2: amplifier power and audible tone

1. With power off, reconnect only amplifier VIN/GND. Leave the microphone and
   speaker disconnected. Power up and measure directly at amplifier terminals:
   VIN-to-GND, SD-to-GND, and ESP32 3V3-to-GND. A powered 5 V setup should read
   near 5 V at VIN and near 3.3 V on the ESP32 rail. The amplifier IC operates
   over 2.5–5.5 V, but that does not prove a particular breakout or power route
   is wired correctly. Watch serial for another 60 seconds.
2. Power off. Wire SD to GPIO27 with the pulldown, and BCLK/LRC/DIN as above.
   Upload/use `speaker_only` only after that rewiring. Inspect
   continuity again. With the speaker still disconnected, run `i` then `s`.
   Confirm MIC disabled, SPK ready and a successful digital transfer.
3. Power off. Connect the speaker only across SPK+/SPK−. SD is enabled by firmware
   as described above. Run `s`, keeping the speaker away from your ear. Repeat it
   several times. Log whether the tone is audible, plus VIN and 3V3 idle/during
   the tone. DMM readings may miss short dips, so a stable reading is not proof
   of good transient response.
4. If adding a connection changes serial behavior, repeat that A/B experiment
   with power off between changes. Keep both supplies and common ground
   connected before attaching any driven signal; never power the amp through
   its I2S inputs. Add BCLK, then LRC, then DIN in separate powered-off steps
   if needed to locate a miswire.
5. If rail sag/noise tracks the amp load, shorten power/ground wiring and check
   existing local bypassing. A 0.1 µF ceramic plus about 100 µF bulk capacitor
   (correct polarity, rated at least 10 V) close to VIN/GND is a useful bench
   trial. If needed, supply the amp from a separate regulated 5 V source with
   common ground; remove its connection to the board's 5 V rail so the supplies
   are not tied together or backfeeding USB.

**Pass:** a repeatable audible tone, stable serial/uptime, and no power collapse.
Digital transfer success alone is insufficient. A wrong SD mode is one candidate;
the current evidence does not establish it as the cause.

## Oscilloscope / logic-analyzer checks

Probe at the ESP32 and again at the amplifier terminals during `s`.

| Signal | Nominal diagnostic-build expectation |
|---|---|
| GPIO14 → BCLK | 256 kHz, 32 bit clocks per complete stereo frame |
| GPIO16 → LRC | 8 kHz frame rate, 16 clocks per half-frame |
| GPIO17 → DIN | Standard I2S, MSB first, one-bit delay after LRC transition; 16-bit signed samples |
| Decoded L/R | Both repeat four samples +2000, four samples −2000: 1 kHz; then zeros |
| GPIO26 mic BCLK | 512 kHz, 64 clocks per frame when MIC enabled |
| GPIO25 mic WS | 8 kHz when MIC enabled |
| GPIO33 mic SD | Left-slot speech data, 24 significant bits carried in 32-bit words |

Use a shared GND reference, 3.3 V-compatible analyzer inputs, and preferably
10 MS/s or faster sampling. The firmware prints configured frequencies, not
measured ones. A basic multimeter cannot validate these clocks or decode DIN.

Absent clock at the ESP32 points toward wrong build/pin/controller setup. A
clock present there but absent at the module points toward continuity, breadboard
rows or loading. Correct clocks but incorrect decoded words point toward format
or data routing. Correct I2S at the amp plus valid VIN/SD and no output shifts
attention to the amp, speaker, solder joints or part identity.

The class-D speaker output is bridged and switches rapidly. **Never attach an
earth-grounded scope ground clip to SPK− or SPK+.** Use a suitably rated
differential probe, or two probe tips on the two outputs with both ground clips
at circuit GND and display CH1−CH2. Don't connect a grounded line input or logic
analyzer across the speaker terminals. Start with I2S and supply measurements.

For supply integrity, use a short probe ground at amplifier VIN and ESP32 3V3,
triggering on negative excursions during `s`. Capture enough detail to distinguish
rail dips from probe-loop pickup. If serial corruption persists, observe UART0
TX at GPIO1: 115200 baud has a nominal 8.68 µs bit period. Compare MCU TX with
the terminal capture before assigning the fault to firmware or USB/UART hardware.

## Gate 3: microphone, then packetized audio

1. After Gate 2 passes, power off, reconnect the INMP441 and upload `esp32dev`.
   Confirm its VDD is 3.3 V, L/R is grounded, and the port is master RX/left/32-bit.
   The INMP441 startup mute lasts 2^18 SCK cycles, approximately 512 ms at this
   clock; this build allows 600 ms at initialization and leaves clocks running.
   [TDK INMP441 datasheet](https://product.tdk.com/system/files/dam/doc/product/sw_piezo/mic/mems-mic/data_sheet/inmp441.pdf).
2. Run `m` in a quiet room, then `m` while speaking at a consistent distance.
   Save the `[MIC]` lines. Both successful captures contain exactly 24,000 PCM
   samples. Expect speech to increase AC RMS and peak range. All zeros suggest
   wiring/channel/power/startup issues; nearly constant data or large DC needs
   slot/format investigation. Persistent clipping means reduce gain after
   confirming data validity. RMS alone cannot distinguish speech from interference.
3. Capture duration should be around 3 seconds plus boundary flushing and
   diagnostics. Exactly 24,000 samples defines duration at the actual measured
   clock; a software millisecond timer does not calibrate the audio clock. The
   original 2.88–2.90 seconds is consistent with queued DMA data, not proof of
   successful fresh capture. The change drains that queue without zeroing it.
4. Run `r`. Require intelligible recorded speech and a complete ending. Keep the
   existing `raw >> 16`, gain 2 conversion until level and raw-word measurements
   justify a change. Do not amplify a disconnected/floating input to hide a fault.
5. Set loss to zero with `l` if necessary, then run `p`. Require 200 received,
   zero missing, byte-for-byte PCM verification and intelligible playback.
6. Toggle `l` to 17 and repeat `p`. Require 189 received / 11 missing, verified
   zeros at those indices, and short gaps rather than displaced/corrupt audio.
   Each missing chunk is 120 samples = 15 ms at 8 kHz; total silence is 165 ms.
7. Repeat `t` and the tone after these operations. Use `h` to disable heartbeat
   after serial is stable. Re-enable only for a specific diagnostic comparison.

**Pass:** all three gates, including human listening and saved measurements.
Only then proceed to SX1262 transport; no real-time or full-duplex LoRa voice is
assumed. No final Heltec V4 pin assignment is established by this bench map.

Record the next evidence in this form:

```text
Environment/banner:
Speaker nominal impedance and measured unpowered resistance:
Amp VIN idle / during s:
Amp SD-to-GND:
ESP32 3V3 idle / during s:
s result / audible yes-no:
Serial-only vs amplifier-connected corruption:
i output and any complete reset log:
Quiet m statistics / speaking m statistics (after tone passes):
Available instruments / I2S measurements:
```
